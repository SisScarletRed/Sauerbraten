This model was created by Pyccna using Cube 2: Sauerbraten, Blender, & Misfit Model 3D programs.
This model's skins were created by Pyccna using Blender, Adobe Photoshop, & Doctor Noob's "Pimp My Gun" (http://pimpmygun.doctornoob.com/index.php)
This model & its skins are released under CC-By-NC License, see https://creativecommons.org/licenses/by-nc/4.0/ for information about this license.
For permission to use the contents of this package outside the scope of this license, contact Pyccna: http://quadropolis.us/user/5493